#!/bin/bash

TODAY=$(date +%d.%m.%Y)
if grep -q $TODAY /etc/not-today/days.cfg; then
	echo "not-today-script Skipping Job at $TODAY"
	exit 0
fi

